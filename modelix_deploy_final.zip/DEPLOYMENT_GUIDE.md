# 🚀 Руководство по деплою сайта Modelix на VPS

## 📋 Предварительные требования

- Ubuntu 22.04 LTS
- Python 3.8+
- Nginx
- PostgreSQL (опционально, можно использовать SQLite)
- SSL сертификат от Let's Encrypt

## 🔧 Установка и настройка

### 1. Подготовка сервера

```bash
# Обновление системы
sudo apt update && sudo apt upgrade -y

# Установка необходимых пакетов
sudo apt install python3 python3-pip python3-venv nginx postgresql postgresql-contrib -y

# Установка Certbot для SSL
sudo apt install certbot python3-certbot-nginx -y
```

### 2. Загрузка проекта

```bash
# Создание директории для проекта
sudo mkdir -p /var/www/modelix
sudo chown -R $USER:$USER /var/www/modelix

# Загрузка архива (замените на ваш путь)
# scp modelix_deploy.zip root@83.166.247.38:/var/www/modelix/

# Распаковка архива
cd /var/www/modelix
unzip modelix_deploy.zip
```

### 3. Настройка виртуального окружения

```bash
# Создание виртуального окружения
python3 -m venv venv
source venv/bin/activate

# Установка зависимостей
pip install -r requirements.txt
```

### 4. Настройка Django

```bash
# Создание миграций
python manage.py makemigrations
python manage.py migrate

# Создание суперпользователя
python manage.py createsuperuser

# Сбор статических файлов
python manage.py collectstatic --noinput

# Заполнение базы данных
python manage.py migrate_data
```

### 5. Настройка Nginx

Создайте файл `/etc/nginx/sites-available/3dmodelix.ru`:

```nginx
server {
    listen 80;
    server_name 3dmodelix.ru www.3dmodelix.ru;

    client_max_body_size 50M;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /static/ {
        alias /var/www/modelix/staticfiles/;
    }

    location /media/ {
        alias /var/www/modelix/media/;
    }
}
```

Активируйте конфигурацию:

```bash
sudo ln -s /etc/nginx/sites-available/3dmodelix.ru /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### 6. Настройка SSL

```bash
# Получение SSL сертификата
sudo certbot --nginx -d 3dmodelix.ru -d www.3dmodelix.ru

# Автоматическое обновление сертификата
sudo crontab -e
# Добавьте строку:
# 0 12 * * * /usr/bin/certbot renew --quiet
```

### 7. Запуск Django

```bash
# Запуск в фоновом режиме
nohup python manage.py runserver 0.0.0.0:8000 > django.log 2>&1 &

# Или с Gunicorn (рекомендуется для продакшена)
pip install gunicorn
gunicorn --bind 0.0.0.0:8000 modelix_site.wsgi:application --daemon
```

## 🔍 Проверка работы

1. Откройте браузер и перейдите на `https://3dmodelix.ru`
2. Проверьте, что все изображения загружаются
3. Проверьте админ-панель: `https://3dmodelix.ru/admin/`

## 🛠️ Управление проектом

### Перезапуск Django
```bash
# Остановка процесса
pkill -f "python manage.py runserver"
# или
pkill -f gunicorn

# Запуск заново
nohup python manage.py runserver 0.0.0.0:8000 > django.log 2>&1 &
```

### Обновление статических файлов
```bash
python manage.py collectstatic --noinput
```

### Просмотр логов
```bash
tail -f django.log
```

## 📁 Структура проекта

```
/var/www/modelix/
├── main/                    # Django приложение
├── modelix_site/           # Настройки Django
├── static/                 # Исходные статические файлы
├── staticfiles/           # Собранные статические файлы
├── media/                 # Загруженные пользователями файлы
├── manage.py              # Django управление
├── requirements.txt       # Зависимости Python
└── DEPLOYMENT_GUIDE.md    # Это руководство
```

## ⚠️ Важные замечания

1. **Безопасность**: Убедитесь, что `DEBUG = False` в настройках
2. **Права доступа**: Установите правильные права на папки media и staticfiles
3. **Резервное копирование**: Регулярно создавайте резервные копии базы данных
4. **Мониторинг**: Следите за логами и производительностью

## 🆘 Решение проблем

### Ошибка 502 Bad Gateway
- Проверьте, что Django запущен на порту 8000
- Проверьте конфигурацию Nginx

### Статические файлы не загружаются
- Выполните `python manage.py collectstatic --noinput`
- Проверьте права доступа к папке staticfiles

### SSL не работает
- Проверьте DNS записи домена
- Убедитесь, что порт 80 и 443 открыты в файрволе

## 📞 Поддержка

При возникновении проблем проверьте:
1. Логи Django: `tail -f django.log`
2. Логи Nginx: `sudo tail -f /var/log/nginx/error.log`
3. Статус сервисов: `sudo systemctl status nginx`
