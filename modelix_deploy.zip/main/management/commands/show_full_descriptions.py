"""
Команда для показа полных описаний услуг
Запускать: python manage.py show_full_descriptions
"""

from django.core.management.base import BaseCommand
from main.models import Service

class Command(BaseCommand):
    help = 'Показывает полные описания услуг'

    def handle(self, *args, **options):
        self.stdout.write("=" * 60)
        self.stdout.write("ПОЛНЫЕ ОПИСАНИЯ УСЛУГ")
        self.stdout.write("=" * 60)
        
        services = Service.objects.all().order_by('order')
        for i, service in enumerate(services, 1):
            self.stdout.write(f"\n{i}. {service.get_service_type_display()} - {service.title}")
            self.stdout.write(f"   Описание: {service.description}")
            self.stdout.write(f"   Активна: {service.is_active}")
            self.stdout.write(f"   Порядок: {service.order}")
            self.stdout.write("-" * 60)
        
        self.stdout.write("\n" + "=" * 60)
        self.stdout.write("ПОКАЗ ЗАВЕРШЕН")
        self.stdout.write("=" * 60)

