#!/usr/bin/env python3
"""
Автоматический скрипт деплоя для VPS
Запускать: python auto_deploy.py
"""

import os
import sys
import subprocess
import django
from pathlib import Path

# Настройка Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'modelix_site.settings_production')
django.setup()

def run_command(command, description):
    """Выполняет команду и выводит результат"""
    print(f"🔄 {description}...")
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        print(f"✅ {description} - успешно")
        if result.stdout:
            print(f"   Вывод: {result.stdout.strip()}")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ {description} - ошибка")
        print(f"   Ошибка: {e.stderr.strip()}")
        return False

def check_environment():
    """Проверяет переменные окружения"""
    print("🔍 Проверяем переменные окружения...")
    
    required_vars = [
        'DJANGO_SECRET_KEY',
        'DB_NAME',
        'DB_USER', 
        'DB_PASSWORD',
        'DB_HOST',
        'DB_PORT'
    ]
    
    missing_vars = []
    for var in required_vars:
        if not os.environ.get(var):
            missing_vars.append(var)
    
    if missing_vars:
        print("❌ Отсутствуют обязательные переменные окружения:")
        for var in missing_vars:
            print(f"   - {var}")
        print("\n📋 Создайте файл .env с переменными:")
        print("DJANGO_SECRET_KEY=your-secret-key-here")
        print("DB_NAME=modelix_db")
        print("DB_USER=modelix_user")
        print("DB_PASSWORD=your-db-password")
        print("DB_HOST=localhost")
        print("DB_PORT=5432")
        print("DOMAIN_NAME=your-domain.com")
        print("SERVER_IP=your-server-ip")
        return False
    
    print("✅ Все переменные окружения настроены")
    return True

def create_directories():
    """Создает необходимые директории"""
    print("📁 Создаем необходимые директории...")
    
    directories = [
        'logs',
        'staticfiles',
        'media',
        'media/portfolio',
        'media/services',
        'media/orders'
    ]
    
    for directory in directories:
        Path(directory).mkdir(parents=True, exist_ok=True)
        print(f"   ✅ Создана директория: {directory}")

def main():
    print("🚀 АВТОМАТИЧЕСКИЙ ДЕПЛОЙ MODELIX САЙТА")
    print("=" * 50)
    
    # Проверяем, что мы в правильной директории
    if not os.path.exists('manage.py'):
        print("❌ Ошибка: manage.py не найден. Запустите скрипт из корня проекта.")
        sys.exit(1)
    
    # 0. Проверяем переменные окружения
    print("\n🔍 ПРОВЕРКА ПЕРЕМЕННЫХ ОКРУЖЕНИЯ")
    print("-" * 40)
    
    if not check_environment():
        print("❌ Настройте переменные окружения перед продолжением")
        sys.exit(1)
    
    # 0.5. Создаем директории
    print("\n📁 СОЗДАНИЕ ДИРЕКТОРИЙ")
    print("-" * 30)
    create_directories()
    
    # 1. Установка зависимостей
    print("\n📦 УСТАНОВКА ЗАВИСИМОСТЕЙ")
    print("-" * 30)
    
    if not run_command("pip install -r requirements_production.txt", 
                      "Установка зависимостей"):
        print("❌ Не удалось установить зависимости")
        sys.exit(1)
    
    # 2. Проверка конфигурации Django
    print("\n🔍 ПРОВЕРКА КОНФИГУРАЦИИ DJANGO")
    print("-" * 40)
    
    if not run_command("python manage.py check --settings=modelix_site.settings_production", 
                      "Проверка конфигурации Django"):
        print("❌ Обнаружены ошибки в конфигурации Django")
        sys.exit(1)
    
    # 3. Выполнение миграций
    print("\n🗄️ МИГРАЦИИ БАЗЫ ДАННЫХ")
    print("-" * 30)
    
    if not run_command("python manage.py migrate --settings=modelix_site.settings_production", 
                      "Выполнение миграций"):
        print("❌ Не удалось выполнить миграции")
        sys.exit(1)
    
    # 4. Сбор статических файлов
    print("\n📁 СБОР СТАТИЧЕСКИХ ФАЙЛОВ")
    print("-" * 30)
    
    if not run_command("python manage.py collectstatic --noinput --settings=modelix_site.settings_production", 
                      "Сбор статических файлов"):
        print("❌ Не удалось собрать статические файлы")
        sys.exit(1)
    
    # 5. Создание данных
    print("\n📋 СОЗДАНИЕ ДАННЫХ")
    print("-" * 30)
    
    if not run_command("python manage.py migrate_data --settings=modelix_site.settings_production", 
                      "Создание данных сайта"):
        print("❌ Не удалось создать данные")
        sys.exit(1)
    
    # 6. Очистка медиафайлов
    if not run_command("python manage.py cleanup_media --settings=modelix_site.settings_production", 
                      "Очистка медиафайлов"):
        print("❌ Не удалось очистить медиафайлы")
        sys.exit(1)
    
    # 7. Проверка изображений
    if not run_command("python manage.py check_images --settings=modelix_site.settings_production", 
                      "Проверка изображений"):
        print("❌ Обнаружены проблемы с изображениями")
        sys.exit(1)
    
    # 8. Проверка админки
    if not run_command("python manage.py check_admin --settings=modelix_site.settings_production", 
                      "Проверка админки"):
        print("❌ Обнаружены проблемы с админкой")
        sys.exit(1)
    
    # 9. Очистка проекта
    if not run_command("python manage.py cleanup_project --settings=modelix_site.settings_production", 
                      "Очистка проекта"):
        print("❌ Не удалось очистить проект")
        sys.exit(1)
    
    # 10. Проверка SSL совместимости
    if not run_command("python manage.py check_ssl --settings=modelix_site.settings_production", 
                      "Проверка SSL совместимости"):
        print("❌ Обнаружены проблемы с SSL")
        sys.exit(1)
    
    # 11. Создание суперпользователя
    print("\n👤 СОЗДАНИЕ СУПЕРПОЛЬЗОВАТЕЛЯ")
    print("-" * 30)
    
    if not run_command("python manage.py create_superuser_auto --settings=modelix_site.settings_production", 
                      "Создание суперпользователя"):
        print("❌ Не удалось создать суперпользователя")
        sys.exit(1)
    
    # 12. Финальная проверка
    print("\n🔍 ФИНАЛЬНАЯ ПРОВЕРКА")
    print("-" * 30)
    
    if not run_command("python manage.py check --settings=modelix_site.settings_production", 
                      "Финальная проверка конфигурации"):
        print("❌ Обнаружены ошибки в финальной конфигурации")
        sys.exit(1)
    
    # 13. Запуск тестового сервера
    print("\n🌐 ГОТОВНОСТЬ К ЗАПУСКУ")
    print("-" * 30)
    
    print("✅ Деплой завершен успешно!")
    print("")
    print("📋 ИНФОРМАЦИЯ ДЛЯ ДОСТУПА:")
    print(f"  🌐 Сайт: https://{os.environ.get('DOMAIN_NAME', 'ваш-домен.ru')}")
    print(f"  👤 Админка: https://{os.environ.get('DOMAIN_NAME', 'ваш-домен.ru')}/admin/")
    print("  🔑 Логин: admin")
    print("  🔑 Пароль: admin123")
    print("")
    print("⚠️ ВАЖНО:")
    print("  1. Смените пароль админа после первого входа")
    print("  2. Настройте SSL сертификат")
    print("  3. Настройте веб-сервер (nginx)")
    print("  4. Настройте systemd сервис")
    print("")
    print("🚀 Для запуска сервера выполните:")
    print("  gunicorn --bind 0.0.0.0:8000 modelix_site.wsgi:application")

if __name__ == "__main__":
    main()

