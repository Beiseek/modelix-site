#!/usr/bin/env python
import os
import sys
import django

# Настройка Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'modelix_site.settings')
django.setup()

from main.models import TechnologyPrice, Material, FAQ, PortfolioItem

def populate_data():
    # Создаем технологии с ценами
    technologies = [
        {'technology': 'FDM', 'price_per_gram': 1.00, 'materials_count': 7, 'production_time': 2},
        {'technology': 'SLA', 'price_per_gram': 1.00, 'materials_count': 7, 'production_time': 2},
        {'technology': 'SLM', 'price_per_gram': 1.00, 'materials_count': 7, 'production_time': 2},
    ]
    
    for tech_data in technologies:
        tech, created = TechnologyPrice.objects.get_or_create(
            technology=tech_data['technology'],
            defaults=tech_data
        )
        if created:
            print(f"Создана технология: {tech.technology}")
    
    # Создаем материалы для каждой технологии
    materials_data = {
        'FDM': [
            'PLA - биоразлагаемый пластик',
            'ABS - прочный инженерный пластик',
            'PETG - химически стойкий материал',
            'TPU - гибкий эластичный материал',
            'Wood Fill - пластик с древесными волокнами',
            'Carbon Fiber - углеволоконный композит',
            'Metal Fill - пластик с металлическими частицами'
        ],
        'SLA': [
            'Standard Resin - базовая фотополимерная смола',
            'Tough Resin - прочная инженерная смола',
            'Flexible Resin - гибкая эластичная смола',
            'Castable Resin - выжигаемая смола для литья',
            'Dental Resin - биосовместимая смола',
            'Clear Resin - прозрачная оптическая смола',
            'High Temp Resin - термостойкая смола'
        ],
        'SLM': [
            'Stainless Steel 316L - нержавеющая сталь',
            'Titanium Ti6Al4V - титановый сплав',
            'Aluminum AlSi10Mg - алюминиевый сплав',
            'Inconel 718 - жаропрочный сплав',
            'Maraging Steel - мартенситно-стареющая сталь',
            'Cobalt Chrome - кобальт-хромовый сплав',
            'Tool Steel - инструментальная сталь'
        ]
    }
    
    for tech_name, materials in materials_data.items():
        tech = TechnologyPrice.objects.get(technology=tech_name)
        for material_name in materials:
            material, created = Material.objects.get_or_create(
                technology=tech,
                name=material_name,
                defaults={'description': f'Высококачественный материал для {tech_name} печати'}
            )
            if created:
                print(f"Создан материал: {material.name}")
    
    # Создаем FAQ
    faqs = [
        {
            'question': 'Какие форматы файлов вы принимаете?',
            'answer': 'Мы работаем с файлами в форматах STL, OBJ, 3MF, STEP, IGES. Также можем принять фотографии для создания 3D модели.',
            'order': 1
        },
        {
            'question': 'Сколько стоит 3D печать?',
            'answer': 'Стоимость рассчитывается исходя из веса изделия, выбранного материала и технологии печати. Базовая цена от 1 рубля за грамм.',
            'order': 2
        },
        {
            'question': 'Как долго изготавливается заказ?',
            'answer': 'Стандартный срок изготовления составляет 2-3 дня. Для срочных заказов возможно изготовление за 24 часа.',
            'order': 3
        },
        {
            'question': 'Какая точность печати?',
            'answer': 'Точность зависит от технологии: FDM ±0.2мм, SLA ±0.05мм, SLM ±0.1мм. Минимальная толщина стенки от 0.8мм.',
            'order': 4
        },
        {
            'question': 'Предоставляете ли вы постобработку?',
            'answer': 'Да, мы предоставляем полный цикл постобработки: удаление поддержек, шлифовка, покраска, сборка сложных изделий.',
            'order': 5
        },
        {
            'question': 'Можете ли вы создать 3D модель по эскизу?',
            'answer': 'Конечно! Наши инженеры создадут 3D модель по вашим чертежам, эскизам или даже фотографиям.',
            'order': 6
        }
    ]
    
    for faq_data in faqs:
        faq, created = FAQ.objects.get_or_create(
            question=faq_data['question'],
            defaults=faq_data
        )
        if created:
            print(f"Создан FAQ: {faq.question}")
    
    # Создаем элементы портфолио
    portfolio_items = [
        {'title': 'Корпус радиатора', 'order': 1},
        {'title': 'Макет небоскреба', 'order': 2},
        {'title': 'Шестерня механизма', 'order': 3},
        {'title': 'Декоративная модель', 'order': 4},
        {'title': 'Функциональная деталь', 'order': 5},
        {'title': 'Архитектурный макет', 'order': 6},
    ]
    
    for item_data in portfolio_items:
        item, created = PortfolioItem.objects.get_or_create(
            title=item_data['title'],
            defaults=item_data
        )
        if created:
            print(f"Создан элемент портфолио: {item.title}")
    
    print("Все данные успешно добавлены!")

if __name__ == '__main__':
    populate_data()
