#!/bin/bash

# Скрипт автоматического деплоя для Modelix сайта
# Использование: ./deploy_production.sh

set -e  # Остановка при ошибке

echo "🚀 Начинаем деплой Modelix сайта..."

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Функция для вывода сообщений
log() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Проверка, что мы на Ubuntu/Debian
if ! command -v apt &> /dev/null; then
    error "Этот скрипт предназначен для Ubuntu/Debian систем"
    exit 1
fi

# Обновление системы
log "Обновляем систему..."
apt update && apt upgrade -y

# Установка необходимых пакетов
log "Устанавливаем необходимые пакеты..."
apt install -y python3 python3-pip python3-venv nginx postgresql postgresql-contrib certbot python3-certbot-nginx git

# Создание пользователя для приложения
log "Создаем пользователя для приложения..."
if ! id "modelix" &>/dev/null; then
    useradd -m -s /bin/bash modelix
    usermod -aG sudo modelix
fi

# Создание директории проекта
PROJECT_DIR="/var/www/modelix"
log "Создаем директорию проекта: $PROJECT_DIR"
mkdir -p $PROJECT_DIR
chown modelix:modelix $PROJECT_DIR

# Переключение на пользователя modelix
log "Переключаемся на пользователя modelix..."
su - modelix << 'EOF'

# Создание виртуального окружения
cd /var/www/modelix
python3 -m venv venv
source venv/bin/activate

# Установка зависимостей
pip install --upgrade pip
pip install -r requirements_production.txt

# Создание директорий для логов
mkdir -p logs
mkdir -p staticfiles
mkdir -p media

EOF

# Настройка PostgreSQL
log "Настраиваем PostgreSQL..."
sudo -u postgres psql << 'EOF'
CREATE DATABASE modelix_db;
CREATE USER modelix_user WITH PASSWORD 'modelix_secure_password_2024!';
GRANT ALL PRIVILEGES ON DATABASE modelix_db TO modelix_user;
ALTER USER modelix_user CREATEDB;
EOF

# Создание .env файла
log "Создаем файл переменных окружения..."
cat > $PROJECT_DIR/.env << 'EOF'
DJANGO_SECRET_KEY=django-insecure-production-key-change-me-2024!
DEBUG=False
DOMAIN_NAME=3dmodelix.ru
SERVER_IP=83.166.247.38
DB_NAME=modelix_db
DB_USER=modelix_user
DB_PASSWORD=modelix_secure_password_2024!
DB_HOST=localhost
DB_PORT=5432
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_HOST_USER=modelix.stl@gmail.com
EMAIL_HOST_PASSWORD=
DEFAULT_FROM_EMAIL=noreply@3dmodelix.ru
EOF

chown modelix:modelix $PROJECT_DIR/.env
chmod 600 $PROJECT_DIR/.env

# Настройка Nginx
log "Настраиваем Nginx..."
cat > /etc/nginx/sites-available/modelix << 'EOF'
server {
    listen 80;
    server_name 3dmodelix.ru www.3dmodelix.ru;
    
    # Временная конфигурация для получения SSL
    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # Статические файлы
    location /static/ {
        alias /var/www/modelix/staticfiles/;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
    
    # Медиа файлы
    location /media/ {
        alias /var/www/modelix/media/;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
EOF

# Активация сайта
ln -sf /etc/nginx/sites-available/modelix /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

# Проверка конфигурации Nginx
nginx -t

# Перезапуск Nginx
systemctl restart nginx
systemctl enable nginx

# Создание systemd сервиса
log "Создаем systemd сервис..."
cat > /etc/systemd/system/modelix.service << 'EOF'
[Unit]
Description=Modelix Django App
After=network.target

[Service]
Type=simple
User=modelix
Group=modelix
WorkingDirectory=/var/www/modelix
Environment=DJANGO_SETTINGS_MODULE=modelix_site.settings_production
ExecStart=/var/www/modelix/venv/bin/gunicorn --workers 3 --bind 127.0.0.1:8000 modelix_site.wsgi:application
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

# Перезагрузка systemd
systemctl daemon-reload
systemctl enable modelix

# Создание скрипта для управления
log "Создаем скрипт управления..."
cat > /usr/local/bin/modelix-manage << 'EOF'
#!/bin/bash

PROJECT_DIR="/var/www/modelix"
cd $PROJECT_DIR
source venv/bin/activate
export DJANGO_SETTINGS_MODULE=modelix_site.settings_production

case "$1" in
    start)
        systemctl start modelix
        echo "Сервис Modelix запущен"
        ;;
    stop)
        systemctl stop modelix
        echo "Сервис Modelix остановлен"
        ;;
    restart)
        systemctl restart modelix
        echo "Сервис Modelix перезапущен"
        ;;
    status)
        systemctl status modelix
        ;;
    logs)
        journalctl -u modelix -f
        ;;
    migrate)
        python manage.py migrate
        ;;
    collectstatic)
        python manage.py collectstatic --noinput
        ;;
    shell)
        python manage.py shell
        ;;
    *)
        echo "Использование: $0 {start|stop|restart|status|logs|migrate|collectstatic|shell}"
        exit 1
        ;;
esac
EOF

chmod +x /usr/local/bin/modelix-manage

log "✅ Деплой завершен!"
echo ""
echo "📋 Следующие шаги:"
echo "1. Загрузите файлы проекта в /var/www/modelix/"
echo "2. Выполните: modelix-manage migrate"
echo "3. Выполните: modelix-manage collectstatic"
echo "4. Запустите: modelix-manage start"
echo "5. Получите SSL: certbot --nginx -d 3dmodelix.ru -d www.3dmodelix.ru"
echo ""
echo "🔧 Управление сервисом:"
echo "- modelix-manage start    - запустить"
echo "- modelix-manage stop     - остановить"
echo "- modelix-manage restart  - перезапустить"
echo "- modelix-manage status   - статус"
echo "- modelix-manage logs     - логи"
echo ""
echo "⚠️  Не забудьте изменить пароли в файле .env!"
