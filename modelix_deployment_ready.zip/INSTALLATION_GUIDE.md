# 🚀 Руководство по установке Modelix сайта

## 📋 Требования

- Ubuntu 20.04+ или Debian 11+
- Минимум 1GB RAM
- Минимум 10GB свободного места
- Домен, указывающий на IP сервера

## 🔧 Быстрая установка

### 1. Подготовка сервера

```bash
# Скачайте и запустите скрипт автоматической установки
wget https://raw.githubusercontent.com/your-repo/modelix/main/deploy_production.sh
chmod +x deploy_production.sh
sudo ./deploy_production.sh
```

### 2. Загрузка файлов проекта

```bash
# Перейдите в директорию проекта
cd /var/www/modelix

# Загрузите файлы проекта (через scp, git clone или другим способом)
# Например, если у вас есть ZIP архив:
unzip modelix-project.zip
chown -R modelix:modelix /var/www/modelix
```

### 3. Настройка базы данных

```bash
# Выполните миграции
sudo modelix-manage migrate

# Соберите статические файлы
sudo modelix-manage collectstatic
```

### 4. Запуск сервиса

```bash
# Запустите сервис
sudo modelix-manage start

# Проверьте статус
sudo modelix-manage status
```

### 5. Получение SSL сертификата

```bash
# Получите SSL сертификат
sudo certbot --nginx -d 3dmodelix.ru -d www.3dmodelix.ru

# Проверьте автообновление
sudo certbot renew --dry-run
```

## 🛠️ Ручная установка

### 1. Обновление системы

```bash
sudo apt update && sudo apt upgrade -y
```

### 2. Установка зависимостей

```bash
sudo apt install -y python3 python3-pip python3-venv nginx postgresql postgresql-contrib certbot python3-certbot-nginx git
```

### 3. Создание пользователя

```bash
sudo useradd -m -s /bin/bash modelix
sudo usermod -aG sudo modelix
```

### 4. Настройка PostgreSQL

```bash
sudo -u postgres psql
```

```sql
CREATE DATABASE modelix_db;
CREATE USER modelix_user WITH PASSWORD 'your_secure_password';
GRANT ALL PRIVILEGES ON DATABASE modelix_db TO modelix_user;
ALTER USER modelix_user CREATEDB;
\q
```

### 5. Настройка проекта

```bash
# Переключитесь на пользователя modelix
sudo su - modelix

# Создайте директорию проекта
mkdir -p /var/www/modelix
cd /var/www/modelix

# Создайте виртуальное окружение
python3 -m venv venv
source venv/bin/activate

# Установите зависимости
pip install --upgrade pip
pip install -r requirements_production.txt
```

### 6. Настройка переменных окружения

Создайте файл `.env` в директории проекта:

```bash
nano .env
```

```env
DJANGO_SECRET_KEY=your-secret-key-here
DEBUG=False
DOMAIN_NAME=3dmodelix.ru
SERVER_IP=83.166.247.38
DB_NAME=modelix_db
DB_USER=modelix_user
DB_PASSWORD=your_secure_password
DB_HOST=localhost
DB_PORT=5432
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_HOST_USER=your-email@gmail.com
EMAIL_HOST_PASSWORD=your-app-password
DEFAULT_FROM_EMAIL=noreply@3dmodelix.ru
```

### 7. Настройка Nginx

```bash
sudo nano /etc/nginx/sites-available/modelix
```

```nginx
server {
    listen 80;
    server_name 3dmodelix.ru www.3dmodelix.ru;
    
    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    location /static/ {
        alias /var/www/modelix/staticfiles/;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
    
    location /media/ {
        alias /var/www/modelix/media/;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

```bash
# Активируйте сайт
sudo ln -sf /etc/nginx/sites-available/modelix /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default

# Проверьте конфигурацию
sudo nginx -t

# Перезапустите Nginx
sudo systemctl restart nginx
sudo systemctl enable nginx
```

### 8. Настройка systemd сервиса

```bash
sudo nano /etc/systemd/system/modelix.service
```

```ini
[Unit]
Description=Modelix Django App
After=network.target

[Service]
Type=simple
User=modelix
Group=modelix
WorkingDirectory=/var/www/modelix
Environment=DJANGO_SETTINGS_MODULE=modelix_site.settings_production
ExecStart=/var/www/modelix/venv/bin/gunicorn --workers 3 --bind 127.0.0.1:8000 modelix_site.wsgi:application
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
```

```bash
# Перезагрузите systemd
sudo systemctl daemon-reload
sudo systemctl enable modelix
```

## 🔧 Управление сервисом

```bash
# Запуск
sudo systemctl start modelix

# Остановка
sudo systemctl stop modelix

# Перезапуск
sudo systemctl restart modelix

# Статус
sudo systemctl status modelix

# Логи
sudo journalctl -u modelix -f
```

## 📁 Структура файлов

```
/var/www/modelix/
├── venv/                 # Виртуальное окружение
├── staticfiles/          # Собранные статические файлы
├── media/               # Загруженные пользователями файлы
├── logs/                # Логи приложения
├── .env                 # Переменные окружения
├── manage.py            # Django управление
├── modelix_site/        # Настройки Django
├── main/                # Основное приложение
└── requirements_production.txt
```

## 🔒 Безопасность

1. **Измените пароли** в файле `.env`
2. **Настройте файрвол**:
   ```bash
   sudo ufw allow 22
   sudo ufw allow 80
   sudo ufw allow 443
   sudo ufw enable
   ```
3. **Регулярно обновляйте** систему и зависимости
4. **Делайте резервные копии** базы данных

## 🐛 Решение проблем

### Проблема: Сайт не загружается

```bash
# Проверьте статус сервиса
sudo systemctl status modelix

# Проверьте логи
sudo journalctl -u modelix -f

# Проверьте Nginx
sudo nginx -t
sudo systemctl status nginx
```

### Проблема: Статические файлы не загружаются

```bash
# Пересоберите статические файлы
sudo modelix-manage collectstatic

# Проверьте права доступа
sudo chown -R modelix:modelix /var/www/modelix/staticfiles
sudo chmod -R 755 /var/www/modelix/staticfiles
```

### Проблема: Ошибки базы данных

```bash
# Проверьте подключение к PostgreSQL
sudo -u postgres psql -c "SELECT 1;"

# Выполните миграции
sudo modelix-manage migrate
```

## 📞 Поддержка

При возникновении проблем:
1. Проверьте логи: `sudo journalctl -u modelix -f`
2. Проверьте статус сервисов: `sudo systemctl status modelix nginx`
3. Проверьте конфигурацию Nginx: `sudo nginx -t`

## 🎯 Готово!

После выполнения всех шагов ваш сайт будет доступен по адресу `https://3dmodelix.ru`
