# 🚀 Руководство по деплою Modelix сайта на VPS

## 📋 Предварительные требования

### На VPS сервере должно быть установлено:
- **Python 3.8+**
- **PostgreSQL 12+**
- **Nginx**
- **Git**
- **pip**

## 🔧 Подготовка сервера

### 1. Установка зависимостей (Ubuntu/Debian)
```bash
# Обновляем систему
sudo apt update && sudo apt upgrade -y

# Устанавливаем Python и зависимости
sudo apt install python3 python3-pip python3-venv postgresql postgresql-contrib nginx git -y

# Устанавливаем дополнительные пакеты для PostgreSQL
sudo apt install libpq-dev python3-dev -y
```

### 2. Настройка PostgreSQL
```bash
# Переходим в PostgreSQL
sudo -u postgres psql

# Создаем базу данных и пользователя
CREATE DATABASE modelix_db;
CREATE USER modelix_user WITH PASSWORD 'ваш_пароль_бд';
GRANT ALL PRIVILEGES ON DATABASE modelix_db TO modelix_user;
\q
```

### 3. Настройка Nginx
```bash
# Создаем конфигурацию сайта
sudo nano /etc/nginx/sites-available/modelix

# Добавляем конфигурацию:
server {
    listen 80;
    server_name ваш-домен.ru www.ваш-домен.ru 83.166.247.38;

    location /static/ {
        alias /path/to/your/project/staticfiles/;
    }

    location /media/ {
        alias /path/to/your/project/media/;
    }

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}

# Активируем сайт
sudo ln -s /etc/nginx/sites-available/modelix /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

## 📦 Деплой проекта

### 1. Клонирование репозитория
```bash
# Клонируем проект
git clone https://github.com/ваш-username/modelix-site.git
cd modelix-site

# Создаем виртуальное окружение
python3 -m venv venv
source venv/bin/activate
```

### 2. Настройка проекта
```bash
# Устанавливаем зависимости
pip install -r requirements_production.txt

# Настраиваем переменные окружения
nano .env
# Добавьте:
# SECRET_KEY=ваш_новый_секретный_ключ
# DB_PASSWORD=ваш_пароль_бд
```

### 3. Настройка production_settings.py
```bash
# Отредактируйте modelix_site/settings_production.py:
# - Замените SECRET_KEY на новый
# - Укажите правильные данные БД
# - Укажите ваш домен в ALLOWED_HOSTS
```

### 4. Запуск проекта
```bash
# Собираем статические файлы
python manage.py collectstatic --noinput --settings=modelix_site.settings_production

# Выполняем миграции
python manage.py migrate --settings=modelix_site.settings_production

# Создаем суперпользователя
python manage.py createsuperuser --settings=modelix_site.settings_production

# Запускаем с Gunicorn
gunicorn --bind 127.0.0.1:8000 modelix_site.wsgi:application --settings=modelix_site.settings_production
```

## 🔄 Автоматический деплой

### 1. Создание systemd сервиса
```bash
sudo nano /etc/systemd/system/modelix.service

# Добавляем:
[Unit]
Description=Modelix Django App
After=network.target

[Service]
User=www-data
Group=www-data
WorkingDirectory=/path/to/your/project
Environment="PATH=/path/to/your/project/venv/bin"
ExecStart=/path/to/your/project/venv/bin/gunicorn --workers 3 --bind 127.0.0.1:8000 modelix_site.wsgi:application --settings=modelix_site.settings_production
ExecReload=/bin/kill -s HUP $MAINPID
Restart=always

[Install]
WantedBy=multi-user.target
```

### 2. Активация сервиса
```bash
sudo systemctl daemon-reload
sudo systemctl enable modelix
sudo systemctl start modelix
sudo systemctl status modelix
```

## 🔐 Безопасность

### 1. Настройка SSL (Let's Encrypt)
```bash
# Устанавливаем Certbot
sudo apt install certbot python3-certbot-nginx -y

# Получаем сертификат
sudo certbot --nginx -d ваш-домен.ru -d www.ваш-домен.ru

# Автообновление
sudo crontab -e
# Добавляем: 0 12 * * * /usr/bin/certbot renew --quiet
```

### 2. Настройка файрвола
```bash
sudo ufw allow 22
sudo ufw allow 80
sudo ufw allow 443
sudo ufw enable
```

## 📝 Обновление проекта

### Автоматическое обновление через Git
```bash
# Используйте скрипт deploy.sh
chmod +x deploy.sh
./deploy.sh
```

### Ручное обновление
```bash
git pull origin main
source venv/bin/activate
pip install -r requirements_production.txt
python manage.py collectstatic --noinput --settings=modelix_site.settings_production
python manage.py migrate --settings=modelix_site.settings_production
sudo systemctl restart modelix
```

## 🐛 Отладка

### Логи
```bash
# Логи Django
tail -f django_errors.log

# Логи Nginx
sudo tail -f /var/log/nginx/error.log

# Логи Gunicorn
sudo journalctl -u modelix -f
```

### Проверка статуса
```bash
# Статус сервисов
sudo systemctl status nginx
sudo systemctl status modelix

# Проверка портов
sudo netstat -tlnp | grep :80
sudo netstat -tlnp | grep :8000
```

## 📞 Поддержка

При возникновении проблем:
1. Проверьте логи
2. Убедитесь, что все сервисы запущены
3. Проверьте права доступа к файлам
4. Убедитесь, что база данных доступна

**Удачного деплоя! 🚀**
