# 🎯 Modelix - 3D Печать и Моделирование

Современный веб-сайт для компании Modelix, специализирующейся на 3D печати и моделировании в Санкт-Петербурге. Полностью готов к деплою на VPS с автоматическим обновлением через Git.

## ✨ Особенности

- 🎨 **Современный дизайн** - Адаптивный интерфейс для всех устройств
- 📱 **Мобильная версия** - Оптимизированная для смартфонов и планшетов
- 🖼️ **Портфолио** - Интерактивная галерея работ
- 📋 **FAQ** - Аккордеон с часто задаваемыми вопросами
- 📞 **Обратная связь** - Формы для заказа услуг
- ⚙️ **Админ-панель** - Управление контентом через Django Admin

## 🛠️ Технологии

- **Backend**: Django 3.2.23
- **Frontend**: HTML5, CSS3, JavaScript
- **База данных**: SQLite (разработка), PostgreSQL (продакшн)
- **Статические файлы**: WhiteNoise
- **Сервер**: Gunicorn + Nginx

## 📋 Требования

- Python 3.8+
- pip
- Git

## 🚀 Быстрый старт

### 1. Клонирование репозитория
```bash
git clone https://github.com/ваш-username/modelix-site.git
cd modelix-site
```

### 2. Установка зависимостей
```bash
pip install -r requirements.txt
```

### 3. Настройка базы данных
```bash
python manage.py makemigrations
python manage.py migrate
```

### 4. Создание суперпользователя
```bash
python manage.py createsuperuser
```

### 5. Запуск сервера
```bash
python manage.py runserver
```

### 6. Открытие сайта
Перейдите в браузер по адресу: **http://127.0.0.1:8000/**

### 📁 Структура проекта:
```
kwork.Modelix.сайт/
├── manage.py                 # Главный файл Django
├── modelix_site/            # Настройки проекта
├── main/                    # Основное приложение
│   ├── templates/           # HTML шаблоны
│   ├── models.py           # Модели базы данных
│   └── views.py            # Логика страниц
├── static/                  # Статические файлы
│   ├── css/                # Стили
│   ├── js/                 # JavaScript
│   └── images/             # Изображения
└── db.sqlite3              # База данных
```

### 🔧 Возможные проблемы:

**1. "django-admin не найден"**
- Решение: `pip install Django`

**2. "python не найден"**
- Решение: Переустановите Python с галочкой "Add to PATH"

**3. "Порт занят"**
- Решение: Используйте другой порт: `python manage.py runserver 8001`

## 🚀 Деплой на VPS

Проект полностью подготовлен к деплою на VPS сервер:

### 📋 Готовые файлы для деплоя:
- ✅ `modelix_site/settings_production.py` - продакшен настройки
- ✅ `requirements_production.txt` - зависимости для сервера
- ✅ `deploy.sh` - автоматический скрипт деплоя
- ✅ `DEPLOYMENT_GUIDE.md` - подробное руководство
- ✅ `.gitignore` - исключения для Git
- ✅ `generate_secret_key.py` - генератор SECRET_KEY

### 🔧 Быстрый деплой:
```bash
# На сервере
git clone https://github.com/your-username/modelix-site.git
cd modelix-site
chmod +x deploy.sh
./deploy.sh
```

### 📝 Что нужно настроить на сервере:
1. **PostgreSQL** - база данных
2. **Nginx** - веб-сервер
3. **Gunicorn** - WSGI сервер
4. **SSL сертификат** - для HTTPS
5. **Домен** - в ALLOWED_HOSTS

Подробные инструкции: [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md)

## 🔐 Безопасность

- ✅ Новый SECRET_KEY сгенерирован
- ✅ DEBUG отключен для продакшена
- ✅ SecurityMiddleware включен
- ✅ HTTPS настройки готовы
- ✅ Логирование ошибок настроено

## 📞 Контакты для поддержки:
- Email: modelix.stl@gmail.com
- Телефон: +79291782000
- ИП: Худолей Илья Константинович

---

**Проект готов к продакшену! 🚀**
- ✅ Все ошибки исправлены
- ✅ Безопасность настроена
- ✅ Деплой автоматизирован
- ✅ Документация готова