#!/bin/bash

# Скрипт для деплоя Django приложения на VPS
echo "🚀 Начинаем деплой Modelix сайта..."

# Проверяем наличие Git
if ! command -v git &> /dev/null; then
    echo "❌ Git не установлен! Установите Git сначала."
    exit 1
fi

# Обновляем код из git
echo "📥 Обновляем код из Git..."
git pull origin main

# Активируем виртуальное окружение (если есть)
if [ -d "venv" ]; then
    echo "🐍 Активируем виртуальное окружение..."
    source venv/bin/activate
elif [ -d ".venv" ]; then
    echo "🐍 Активируем виртуальное окружение..."
    source .venv/bin/activate
fi

# Устанавливаем/обновляем зависимости
echo "📦 Устанавливаем зависимости..."
pip install -r requirements_production.txt

# Собираем статические файлы
echo "📁 Собираем статические файлы..."
python manage.py collectstatic --noinput --settings=modelix_site.settings_production

# Выполняем миграции
echo "🗄️ Выполняем миграции базы данных..."
python manage.py migrate --settings=modelix_site.settings_production

# Создаем суперпользователя (если нужно)
echo "👤 Проверяем суперпользователя..."
python manage.py shell --settings=modelix_site.settings_production << EOF
from django.contrib.auth.models import User
if not User.objects.filter(is_superuser=True).exists():
    print("Создайте суперпользователя командой: python manage.py createsuperuser --settings=modelix_site.settings_production")
else:
    print("Суперпользователь уже существует")
EOF

# Перезапускаем сервисы (настройте под ваш сервер)
echo "🔄 Перезапускаем веб-сервер..."
# Раскомментируйте и настройте под ваш сервер:
# sudo systemctl restart nginx
# sudo systemctl restart gunicorn

echo "✅ Деплой завершен!"
echo "🌐 Сайт должен быть доступен по адресу: http://83.166.247.38"
