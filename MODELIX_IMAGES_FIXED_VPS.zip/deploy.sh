#!/bin/bash

# Скрипт для деплоя Django приложения на VPS
echo "Начинаем деплой Modelix сайта..."

# Обновляем код из git
echo "Обновляем код из Git..."
git pull origin main

# Активируем виртуальное окружение (если есть)
if [ -d "venv" ]; then
    echo "Активируем виртуальное окружение..."
    source venv/bin/activate
fi

# Устанавливаем/обновляем зависимости
echo "Устанавливаем зависимости..."
pip install -r requirements.txt

# Собираем статические файлы
echo "Собираем статические файлы..."
python manage.py collectstatic --noinput --settings=modelix_site.settings_production

# Выполняем миграции
echo "Выполняем миграции базы данных..."
python manage.py migrate --settings=modelix_site.settings_production

# Перезапускаем сервисы (настройте под ваш сервер)
echo "Перезапускаем веб-сервер..."
# sudo systemctl restart nginx
# sudo systemctl restart gunicorn

echo "Деплой завершен!"
