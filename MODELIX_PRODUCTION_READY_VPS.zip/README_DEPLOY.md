# Инструкция по деплою Modelix на VPS

## Предварительные требования

1. **VPS с Ubuntu 20.04+**
2. **Python 3.7+**
3. **PostgreSQL**
4. **Nginx**
5. **Git**

## Шаги установки

### 1. Подготовка сервера

```bash
# Обновляем систему
sudo apt update && sudo apt upgrade -y

# Устанавливаем необходимые пакеты
sudo apt install python3-pip python3-venv postgresql postgresql-contrib nginx git -y
```

### 2. Настройка базы данных

```bash
# Входим в PostgreSQL
sudo -u postgres psql

# Создаем базу данных и пользователя
CREATE DATABASE modelix_db;
CREATE USER modelix_user WITH PASSWORD 'your_strong_password';
GRANT ALL PRIVILEGES ON DATABASE modelix_db TO modelix_user;
\q
```

### 3. Клонирование проекта

```bash
cd /var/www/
sudo git clone YOUR_REPOSITORY_URL modelix
sudo chown -R $USER:$USER /var/www/modelix
cd modelix
```

### 4. Настройка виртуального окружения

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 5. Настройка переменных окружения

```bash
# Создаем файл .env
nano .env

# Добавляем переменные:
SECRET_KEY=your_secret_key_here
DB_NAME=modelix_db
DB_USER=modelix_user
DB_PASSWORD=your_strong_password
DB_HOST=localhost
DB_PORT=5432
```

### 6. Запуск миграций

```bash
python manage.py migrate --settings=modelix_site.settings_production
python manage.py collectstatic --noinput --settings=modelix_site.settings_production
python manage.py createsuperuser --settings=modelix_site.settings_production
```

### 7. Настройка Gunicorn

```bash
# Создаем systemd сервис
sudo nano /etc/systemd/system/modelix.service

# Содержимое файла:
[Unit]
Description=Modelix Django app
After=network.target

[Service]
User=www-data
Group=www-data
WorkingDirectory=/var/www/modelix
Environment="PATH=/var/www/modelix/venv/bin"
ExecStart=/var/www/modelix/venv/bin/gunicorn --workers 3 --bind unix:/var/www/modelix/modelix.sock modelix_site.wsgi:application --env DJANGO_SETTINGS_MODULE=modelix_site.settings_production
Restart=always

[Install]
WantedBy=multi-user.target
```

### 8. Настройка Nginx

```bash
# Создаем конфигурацию Nginx
sudo nano /etc/nginx/sites-available/modelix

# Содержимое файла:
server {
    listen 80;
    server_name your_domain.com www.your_domain.com;

    location = /favicon.ico { access_log off; log_not_found off; }
    
    location /static/ {
        root /var/www/modelix;
    }
    
    location /media/ {
        root /var/www/modelix;
    }

    location / {
        include proxy_params;
        proxy_pass http://unix:/var/www/modelix/modelix.sock;
    }
}
```

### 9. Активация сервисов

```bash
# Активируем сайт
sudo ln -s /etc/nginx/sites-available/modelix /etc/nginx/sites-enabled
sudo nginx -t
sudo systemctl restart nginx

# Запускаем Gunicorn
sudo systemctl start modelix
sudo systemctl enable modelix
```

## Автодеплой

Для автоматического деплоя используйте скрипт `deploy.sh`:

```bash
chmod +x deploy.sh
./deploy.sh
```

## Важные замечания

1. **Замените все пароли** на сильные
2. **Настройте SSL сертификат** (Let's Encrypt)
3. **Настройте резервное копирование** базы данных
4. **Проверьте права доступа** к файлам
5. **Замените файлы с кириллицей** на renamed версии

## Файлы с кириллицей

⚠️ **ВНИМАНИЕ!** Следующие файлы содержат кириллицу и могут вызвать проблемы:

- `static/images/принтер.jpg` → `static/images_renamed/printer.jpg`
- `static/images/первый блок.png` → `static/images_renamed/hero_block.png`
- И другие в папке `static/images_renamed/`

Обновите пути в коде или переименуйте файлы.
