from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.contrib import messages
from .models import PrintOrder, PortfolioItem, CallRequest, Service, SocialLink, ContactInfo, FAQ, HeroImage
import json

def index(request):
    """Главная страница"""
    # Получаем данные для отображения
    portfolio_items = PortfolioItem.objects.all()  # Все работы
    services = Service.objects.filter(is_active=True).order_by('order')  # Активные услуги
    social_links = SocialLink.objects.filter(is_active=True).order_by('order')  # Активные социальные ссылки
    faq_items = FAQ.objects.filter(is_active=True).order_by('order')  # Активные FAQ
    
    # Получаем контактную информацию (создаем если не существует)
    contact_info, created = ContactInfo.objects.get_or_create(
        defaults={
            'phone': '+7 (929) 178-20-00',
            'email': 'modelix.stl@gmail.com',
            'work_hours': 'ПН-ПТ 10:00-20:00',
            'owner_name': 'Худолей Илья Константинович',
            'inn': '780618190040'
        }
    )
    
    # Получаем hero изображение (создаем если не существует)
    hero_image, created = HeroImage.objects.get_or_create(
        defaults={
            'title': 'Главное изображение',
            'image': 'services/hero_block.png',
            'alt_text': '3D принтер',
            'is_active': True
        }
    )
    
    context = {
        'portfolio_items': portfolio_items,
        'services': services,
        'social_links': social_links,
        'contact_info': contact_info,
        'faq_items': faq_items,
        'hero_image': hero_image,
    }
    
    return render(request, 'main/index.html', context)

def submit_order(request):
    """Обработка заявки на печать"""
    
    if request.method == 'POST':
        try:
            name = request.POST.get('name', '').strip()
            phone = request.POST.get('phone', '').strip()
            email = request.POST.get('email', '').strip()
            message = request.POST.get('message', '').strip()
            file = request.FILES.get('file')
            
            
            if not all([name, phone, email]):
                return JsonResponse({'success': False, 'error': 'Заполните все обязательные поля'})
            
            order = PrintOrder.objects.create(
                name=name,
                phone=phone,
                email=email,
                message=message,
                file=file
            )
            
            return JsonResponse({'success': True, 'message': 'Заявка успешно отправлена!'})
            
        except Exception as e:
            return JsonResponse({'success': False, 'error': f'Произошла ошибка: {str(e)}'})
    
    return JsonResponse({'success': False, 'error': 'Метод не поддерживается'})



def submit_call_request(request):
    """Обработка заявки на звонок"""
    if request.method == 'POST':
        try:
            name = request.POST.get('name', '').strip()
            phone = request.POST.get('phone', '').strip()
            
            if not all([name, phone]):
                return JsonResponse({'success': False, 'error': 'Заполните все поля'})
            
            call_request = CallRequest.objects.create(
                name=name,
                phone=phone
            )
            
            return JsonResponse({'success': True, 'message': 'Заявка на звонок принята!'})
            
        except Exception as e:
            return JsonResponse({'success': False, 'error': 'Произошла ошибка при отправке заявки'})
    
    return JsonResponse({'success': False, 'error': 'Метод не поддерживается'})