"""
Команда для проверки содержимого базы данных
Запускать: python manage.py check_database
"""

from django.core.management.base import BaseCommand
from main.models import Service, FAQ, PortfolioItem, ContactInfo, SocialLink, PrintOrder, CallRequest

class Command(BaseCommand):
    help = 'Проверяет содержимое базы данных'

    def handle(self, *args, **options):
        self.stdout.write("=" * 60)
        self.stdout.write("ПРОВЕРКА БАЗЫ ДАННЫХ MODELIX")
        self.stdout.write("=" * 60)

        # Услуги (Наши 3D-возможности)
        self.stdout.write("\n🔧 УСЛУГИ (Наши 3D-возможности):")
        services = Service.objects.all()
        if services:
            for i, service in enumerate(services, 1):
                self.stdout.write(f"{i}. {service.get_service_type_display()} - {service.title}")
                self.stdout.write(f"   Описание: {service.description[:150]}...")
                self.stdout.write(f"   Активна: {service.is_active}")
                self.stdout.write(f"   Порядок: {service.order}")
                self.stdout.write("")
        else:
            self.stdout.write("   ❌ Услуги не найдены")

        # FAQ
        self.stdout.write("\n❓ ЧАСТО ЗАДАВАЕМЫЕ ВОПРОСЫ:")
        faqs = FAQ.objects.filter(is_active=True).order_by('order')
        if faqs:
            for i, faq in enumerate(faqs, 1):
                self.stdout.write(f"{i}. {faq.question}")
                self.stdout.write(f"   Ответ: {faq.answer[:100]}...")
                self.stdout.write("")
        else:
            self.stdout.write("   ❌ FAQ не найдены")

        # Портфолио
        self.stdout.write("\n🎨 ПОРТФОЛИО:")
        portfolio = PortfolioItem.objects.all().order_by('order')
        if portfolio:
            for i, item in enumerate(portfolio, 1):
                self.stdout.write(f"{i}. {item.title}")
                self.stdout.write(f"   Описание: {item.description[:100]}...")
                self.stdout.write(f"   Порядок: {item.order}")
                self.stdout.write("")
        else:
            self.stdout.write("   ❌ Портфолио не найдено")

        # Контактная информация
        self.stdout.write("\n📞 КОНТАКТНАЯ ИНФОРМАЦИЯ:")
        contact = ContactInfo.objects.first()
        if contact:
            self.stdout.write(f"Телефон: {contact.phone}")
            self.stdout.write(f"Email: {contact.email}")
            self.stdout.write(f"Часы работы: {contact.work_hours}")
            self.stdout.write(f"Владелец: {contact.owner_name}")
            self.stdout.write(f"ИНН: {contact.inn}")
        else:
            self.stdout.write("   ❌ Контактная информация не найдена")

        # Социальные ссылки
        self.stdout.write("\n🌐 СОЦИАЛЬНЫЕ ССЫЛКИ:")
        social_links = SocialLink.objects.filter(is_active=True).order_by('order')
        if social_links:
            for i, link in enumerate(social_links, 1):
                self.stdout.write(f"{i}. {link.get_platform_display()}: {link.url}")
        else:
            self.stdout.write("   ❌ Социальные ссылки не найдены")

        # Заявки на печать
        self.stdout.write("\n📋 ЗАЯВКИ НА ПЕЧАТЬ:")
        orders = PrintOrder.objects.all().order_by('-created_at')[:5]  # Последние 5
        if orders:
            for i, order in enumerate(orders, 1):
                self.stdout.write(f"{i}. {order.name} - {order.created_at.strftime('%d.%m.%Y %H:%M')}")
                self.stdout.write(f"   Телефон: {order.phone}")
                self.stdout.write(f"   Email: {order.email}")
                self.stdout.write(f"   Обработано: {order.is_processed}")
                self.stdout.write("")
        else:
            self.stdout.write("   ❌ Заявки на печать не найдены")

        # Заявки на звонок
        self.stdout.write("\n📞 ЗАЯВКИ НА ЗВОНОК:")
        calls = CallRequest.objects.all().order_by('-created_at')[:5]  # Последние 5
        if calls:
            for i, call in enumerate(calls, 1):
                self.stdout.write(f"{i}. {call.name} - {call.created_at.strftime('%d.%m.%Y %H:%M')}")
                self.stdout.write(f"   Телефон: {call.phone}")
                self.stdout.write(f"   Обработано: {call.is_processed}")
                self.stdout.write("")
        else:
            self.stdout.write("   ❌ Заявки на звонок не найдены")

        self.stdout.write("\n" + "=" * 60)
        self.stdout.write("ПРОВЕРКА ЗАВЕРШЕНА")
        self.stdout.write("=" * 60)
