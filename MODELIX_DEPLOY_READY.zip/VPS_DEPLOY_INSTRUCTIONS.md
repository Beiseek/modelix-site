# 🚀 ИСПРАВЛЕННАЯ Инструкция по деплою Modelix на VPS

## ⚠️ ВАЖНО: Используйте исправленные файлы!

### 📁 Исправленные файлы:
- `modelix_site/settings_production_fixed.py` - исправленные настройки
- `requirements_production_fixed.txt` - синхронизированные зависимости  
- `auto_deploy_fixed.py` - исправленный скрипт деплоя
- `env_example.txt` - пример переменных окружения

## 🔧 Исправленные проблемы:

### 1. **Безопасность**
- ✅ SECRET_KEY через переменные окружения
- ✅ DEBUG = False для продакшена
- ✅ Конкретные ALLOWED_HOSTS вместо wildcard
- ✅ Включены все middleware безопасности
- ✅ Полные настройки SSL/HTTPS

### 2. **База данных**
- ✅ Безопасные настройки PostgreSQL
- ✅ Переменные окружения для паролей
- ✅ Правильная конфигурация подключения

### 3. **Статические файлы**
- ✅ Правильный STATIC_ROOT
- ✅ Убраны конфликтующие STATICFILES_DIRS
- ✅ WhiteNoise настроен корректно

### 4. **Зависимости**
- ✅ Синхронизированные версии
- ✅ Добавлены необходимые пакеты
- ✅ Обновлены до стабильных версий

## 📋 Подготовка VPS

### 1. Обновление системы
```bash
sudo apt update && sudo apt upgrade -y
```

### 2. Установка необходимых пакетов
```bash
sudo apt install -y python3 python3-pip python3-venv nginx postgresql postgresql-contrib git
```

### 3. Создание пользователя для проекта
```bash
sudo adduser modelix
sudo usermod -aG sudo modelix
su - modelix
```

## 🗄️ Настройка PostgreSQL

### 1. Создание базы данных
```bash
sudo -u postgres psql
```

```sql
CREATE DATABASE modelix_db;
CREATE USER modelix_user WITH PASSWORD 'ваш_безопасный_пароль';
GRANT ALL PRIVILEGES ON DATABASE modelix_db TO modelix_user;
ALTER USER modelix_user CREATEDB;
\q
```

## 📁 Загрузка проекта

### 1. Клонирование репозитория
```bash
cd /home/modelix
git clone https://github.com/Beiseek/modelix-site.git
cd modelix-site
```

### 2. Создание виртуального окружения
```bash
python3 -m venv venv
source venv/bin/activate
```

### 3. Настройка переменных окружения
```bash
# Создаем файл .env
cp env_example.txt .env
nano .env
```

**Заполните .env файл:**
```bash
DJANGO_SECRET_KEY=сгенерируйте-новый-секретный-ключ
DEBUG=False
DB_NAME=modelix_db
DB_USER=modelix_user
DB_PASSWORD=ваш_безопасный_пароль_бд
DB_HOST=localhost
DB_PORT=5432
DOMAIN_NAME=ваш-домен.ru
SERVER_IP=ваш-ip-адрес
```

### 4. Установка зависимостей
```bash
pip install -r requirements_production_fixed.txt
```

## ⚙️ Настройка Django

### 1. Использование исправленных настроек
```bash
# Переименовываем исправленные настройки
mv modelix_site/settings_production_fixed.py modelix_site/settings_production.py
```

### 2. Выполнение миграций
```bash
python manage.py migrate --settings=modelix_site.settings_production
```

### 3. Сбор статических файлов
```bash
python manage.py collectstatic --settings=modelix_site.settings_production --noinput
```

### 4. Автоматическая настройка данных
```bash
python auto_deploy_fixed.py
```

## 🌐 Настройка Nginx

### 1. Создание конфигурации
```bash
sudo nano /etc/nginx/sites-available/modelix
```

```nginx
server {
    listen 80;
    server_name ваш-домен.ru www.ваш-домен.ru;
    
    # Редирект на HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name ваш-домен.ru www.ваш-домен.ru;
    
    # SSL сертификаты (будут настроены certbot)
    ssl_certificate /etc/letsencrypt/live/ваш-домен.ru/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/ваш-домен.ru/privkey.pem;
    
    # SSL настройки
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384;
    ssl_prefer_server_ciphers off;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;
    
    # Безопасность
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    
    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-Host $host;
        proxy_set_header X-Forwarded-Port $server_port;
    }
    
    location /static/ {
        alias /home/modelix/modelix-site/staticfiles/;
        expires 1y;
        add_header Cache-Control "public, immutable";
        access_log off;
    }
    
    location /media/ {
        alias /home/modelix/modelix-site/media/;
        expires 1y;
        add_header Cache-Control "public, immutable";
        access_log off;
    }
    
    # Безопасность
    location ~ /\. {
        deny all;
        access_log off;
        log_not_found off;
    }
    
    location ~ /(\.env|\.git) {
        deny all;
        access_log off;
        log_not_found off;
    }
}
```

### 2. Активация сайта
```bash
sudo ln -s /etc/nginx/sites-available/modelix /etc/nginx/sites-enabled/
sudo rm /etc/nginx/sites-enabled/default
sudo nginx -t
sudo systemctl reload nginx
```

## 🔒 Настройка SSL (Let's Encrypt)

### 1. Установка Certbot
```bash
sudo apt install certbot python3-certbot-nginx
```

### 2. Получение SSL сертификата
```bash
sudo certbot --nginx -d ваш-домен.ru -d www.ваш-домен.ru
```

### 3. Автоматическое обновление
```bash
sudo crontab -e
# Добавьте строку:
0 12 * * * /usr/bin/certbot renew --quiet
```

## 🚀 Запуск проекта

### 1. Создание systemd сервиса
```bash
sudo nano /etc/systemd/system/modelix.service
```

```ini
[Unit]
Description=Modelix Django App
After=network.target postgresql.service

[Service]
User=modelix
Group=modelix
WorkingDirectory=/home/modelix/modelix-site
Environment="PATH=/home/modelix/modelix-site/venv/bin"
Environment="DJANGO_SETTINGS_MODULE=modelix_site.settings_production"
ExecStart=/home/modelix/modelix-site/venv/bin/gunicorn --workers 3 --bind 127.0.0.1:8000 --timeout 120 modelix_site.wsgi:application
ExecReload=/bin/kill -s HUP $MAINPID
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

### 2. Запуск сервиса
```bash
sudo systemctl daemon-reload
sudo systemctl enable modelix
sudo systemctl start modelix
sudo systemctl status modelix
```

## ✅ Проверка работы

### 1. Проверка сервисов
```bash
sudo systemctl status modelix
sudo systemctl status nginx
sudo systemctl status postgresql
```

### 2. Проверка логов
```bash
sudo journalctl -u modelix -f
sudo tail -f /var/log/nginx/error.log
sudo tail -f /home/modelix/modelix-site/logs/django_errors.log
```

### 3. Тестирование сайта
- Откройте https://ваш-домен.ru в браузере
- Проверьте HTTPS редирект
- Проверьте все страницы и функции
- Проверьте админку: https://ваш-домен.ru/admin/

## 🔧 Полезные команды

### Перезапуск сервисов
```bash
sudo systemctl restart modelix
sudo systemctl restart nginx
```

### Обновление проекта
```bash
cd /home/modelix/modelix-site
git pull
source venv/bin/activate
pip install -r requirements_production_fixed.txt
python manage.py migrate --settings=modelix_site.settings_production
python manage.py collectstatic --settings=modelix_site.settings_production --noinput
sudo systemctl restart modelix
```

### Проверка SSL
```bash
sudo certbot certificates
sudo certbot renew --dry-run
```

## 📊 Мониторинг

### Логи Django
```bash
sudo journalctl -u modelix -f
tail -f /home/modelix/modelix-site/logs/django_errors.log
```

### Логи Nginx
```bash
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log
```

### Использование ресурсов
```bash
htop
df -h
free -h
```

## 🆘 Решение проблем

### Если сайт не загружается
1. Проверьте статус сервисов: `sudo systemctl status modelix nginx`
2. Проверьте логи: `sudo journalctl -u modelix -f`
3. Проверьте конфигурацию Nginx: `sudo nginx -t`
4. Проверьте переменные окружения: `cat .env`

### Если SSL не работает
1. Проверьте сертификаты: `sudo certbot certificates`
2. Проверьте конфигурацию Nginx
3. Убедитесь, что порты 80 и 443 открыты
4. Проверьте DNS настройки домена

### Если база данных не подключается
1. Проверьте статус PostgreSQL: `sudo systemctl status postgresql`
2. Проверьте настройки в `.env` файле
3. Проверьте права пользователя базы данных
4. Проверьте подключение: `psql -h localhost -U modelix_user -d modelix_db`

## 🎯 Финальная проверка

После деплоя убедитесь, что:
- ✅ Сайт открывается по HTTPS
- ✅ Все страницы загружаются
- ✅ Формы работают
- ✅ Админка доступна
- ✅ Статические файлы загружаются
- ✅ Медиафайлы отображаются
- ✅ SSL сертификат действителен
- ✅ Логи не содержат ошибок

**Проект готов к работе! 🚀**

## 📝 Дополнительные рекомендации

### Безопасность
- Регулярно обновляйте зависимости
- Мониторьте логи на предмет подозрительной активности
- Используйте сильные пароли
- Настройте firewall (ufw)

### Производительность
- Настройте кеширование (Redis/Memcached)
- Оптимизируйте изображения
- Используйте CDN для статических файлов
- Мониторьте использование ресурсов

### Резервное копирование
- Настройте автоматическое резервное копирование БД
- Делайте бэкапы медиафайлов
- Сохраняйте конфигурационные файлы
