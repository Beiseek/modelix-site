# ОБНОВЛЕНИЕ: Центрирование футера

## Что изменилось
Изменен только **один файл**: `static/css/styles.css`

## Внесенные изменения в CSS:

### 1. `.footer-content` (строка ~2814)
```css
.footer-content {
    display: grid;
    grid-template-columns: 1fr 2fr 1fr;
    gap: 60px;
    align-items: center;        /* было: start */
    margin-bottom: 40px;
    max-width: 1000px;
    margin-left: auto;          /* было: 0 */
    margin-right: auto;
    text-align: center;         /* добавлено */
}
```

### 2. `.footer-logo` (строка ~2826)
```css
.footer-logo {
    display: flex;
    align-items: center;
    justify-content: center;    /* добавлено */
    gap: 16px;
    font-size: 32px;
    font-weight: 700;
}
```

### 3. `.footer-social` (строка ~2863)
```css
.footer-social {
    display: flex;
    gap: 20px;
    justify-content: center;    /* было: flex-end */
    align-items: center;
    flex-direction: column;
    padding: 20px 0;
}
```

### 4. `.social-icons-row` (строка ~2879)
```css
.social-icons-row {
    display: flex;
    gap: 16px;
    justify-content: center;    /* было: flex-end */
    /* убран margin-right: -80px; */
}
```

## Как применить обновление:

1. **Скопировать файл** `static/css/styles.css` в ваш проект
2. **Заменить** существующий файл
3. **Перезапустить** веб-сервер

## Результат:
- Футер полностью выровнен по центру
- Логотип, контакты, социальные ссылки - все по центру
- Улучшен внешний вид и баланс

**Дата**: 10 сентября 2025
